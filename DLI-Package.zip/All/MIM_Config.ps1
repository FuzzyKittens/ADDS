#Requires -module xActiveDirectory

<# 
    .DESCRIPTION 
        This configuration join a server to a domain and add all prerequesites
        to install Microsoft Identity Manager. 
#>

Configuration MIM_Prepare
{
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.Management.Automation.PSCredential]
        $DomainAdministratorCredential
    )

    Import-DscResource -ModuleName xComputerManagement

    node $AllNodes.NodeName
    {
        foreach ($feature in $WindowsFeatures)
        {
            WindowsFeature $feature
            {
                Name = $feature
                Ensure = 'Present'
            }
        }

        xComputer JoinDomain
        {
            Name       = 'MIM'
            DomainName = $DomainName
            Credential = $DomainCreds
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName   = 'localhost'
            DomainName = 'contoso.com'
        }
    )
    WindowsFeatures = @(
        'Web-WebServer'
        'NET-Framework-Features'
        'NET-Framework-45-Features'
        'RSAT-AD-PowerShell'
        'Web-Mgmt-Tools'
        'Windows-Identity-Foundation'
        'Server-Media-Foundation'
        'Xps-Viewer'
    )
}
