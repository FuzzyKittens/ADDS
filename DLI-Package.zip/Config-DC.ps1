<#PSScriptInfo
.VERSION 1.0
.GUID 86c0280c-6b48-4689-815d-5bc0692845a4
.AUTHOR Microsoft Corporation
.COMPANYNAME Microsoft Corporation
.COPYRIGHT (c) Microsoft Corporation. All rights reserved.
.TAGS DSCConfiguration
.LICENSEURI https://github.com/PowerShell/ActiveDirectoryDsc/blob/master/LICENSE
.PROJECTURI https://github.com/PowerShell/ActiveDirectoryDsc
.ICONURI
.EXTERNALMODULEDEPENDENCIES
.REQUIREDSCRIPTS
.EXTERNALSCRIPTDEPENDENCIES
.RELEASENOTES
.PRIVATEDATA
#>

#Requires -module ActiveDirectoryDsc, NetworkingDsc

<#
    .DESCRIPTION
        This configuration will create a new domain with a new forest and a forest
        functional level of Server 2016.
#>
Configuration ADDS
{
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.Management.Automation.PSCredential]
        $Credential,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.Management.Automation.PSCredential]
        $SafeModePassword,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $DomainName
    )

    Import-DscResource -ModuleName ActiveDirectoryDsc, NetworkingDsc

    $Interface = Get-NetAdapter | Where-Object Name -Like "Ethernet*" | Select-Object -First 1
    $InterfaceAlias = $($Interface.Name)

    $adUsers = (
        'MIMINSTALL',
        'MIMMA',
        'MIMSync',
        'MIMService',
        'MIMSSPR',
        'SharePoint',
        'SqlServer',
        'BackupAdmin',
        'MIMpool'
    )
    
    $adGroups = (
        'MIMSyncAdmins',
        'MIMSyncOperators',
        'MIMSyncJoiners',
        'MIMSyncBrowse',
        'MIMSyncPasswordSet'
    )

    node 'localhost'
    {
        WindowsFeature 'ADDS'
        {
            Name   = 'AD-Domain-Services'
            Ensure = 'Present'
        }

        WindowsFeature 'RSAT'
        {
            Name   = 'RSAT-AD-PowerShell'
            Ensure = 'Present'
        }

        ADDomain $DomainName
        {
            DomainName                    = $DomainName
            Credential                    = $Credential
            SafemodeAdministratorPassword = $SafeModePassword
            ForestMode                    = 'WinThreshold'
        }
        
        DnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
            DependsOn = "[WindowsFeature]DNS"
        }

        foreach ($adUser in $adUsers)
        {
            ADUser $adUser
            {
                Ensure = "Present"
                DomainName = $DomainName
                Credential = $DomainCreds
                UserName = $adUser
                Password = ConvertTo-SecureString -AsPlainText '!A@S3d4f5g6h7j8k' -Force
                PasswordNeverExpires = $true
            }
        }

        foreach ($adGroup in $adGroups)
        {
            ADGroup $adGroup
            {
                Ensure = "Present"
                GroupName = $adGroup
            }
        }

        ADGroup AddMembersToMIMSyncAdminsGroup
        {
            Ensure = "Present"
            GroupName = "MIMSyncAdmins"
            Members = (
                "xAdmin",
                "MIMService",
                "MIMInstall"
            )
        }
    }
}