<#PSScriptInfo 
.VERSION 1.0 
.GUID 86c0280c-6b48-4689-815d-5bc0692845a4 
.AUTHOR Microsoft Corporation 
.COMPANYNAME Microsoft Corporation 
.COPYRIGHT (c) Microsoft Corporation. All rights reserved. 
.TAGS DSCConfiguration 
.LICENSEURI https://github.com/PowerShell/xActiveDirectory/blob/master/LICENSE 
.PROJECTURI https://github.com/PowerShell/xActiveDirectory 
.ICONURI 
.EXTERNALMODULEDEPENDENCIES 
.REQUIREDSCRIPTS 
.EXTERNALSCRIPTDEPENDENCIES 
.RELEASENOTES 
.PRIVATEDATA 
#>

#Requires -module xActiveDirectory

<# 
    .DESCRIPTION 
        This configuration will create a new domain with a new forest and a forest 
        functional level of Server 2016. 
#>

Configuration NewForest_Config
{
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.Management.Automation.PSCredential]
        $DomainAdministratorCredential
    )

    Import-DscResource -ModuleName xActiveDirectory, xNetworking

    $Interface = Get-NetAdapter | Where-Object Name -Like "Ethernet*" | Select-Object -First 1
    $InterfaceAlias = $($Interface.Name)

    node $AllNodes.NodeName
    {
        foreach ($feature in $WindowsFeatures)
        {
            WindowsFeature $feature
            {
                Name = $feature
                Ensure = 'Present'
            }
        }

        xADDomain $Node.DomainName
        {
            DomainName                    = $Node.DomainName
            DomainAdministratorCredential = $DomainAdministratorCredential
            SafemodeAdministratorPassword = $DomainAdministratorCredential
        }

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
        }

        foreach ($adUser in $adUsers)
        {
            xADUser $adUser
            {
                Ensure = "Present"
                DomainName = $DomainName
                DomainAdministratorCredential = $DomainAdministratorCredential
                UserName = $adUser
                Password = $DomainAdministratorCredential
                PasswordNeverExpires = $true
            }
        }

        foreach ($adGroup in $adGroups)
        {
            xADGroup $adGroup
            {
                Ensure = "Present"
                GroupName = $adGroup
            }
        }

        xADGroup AddMembersToMIMSyncAdminsGroup
        {
            Ensure = "Present"
            GroupName = "MIMSyncAdmins"
            Members = (
                "xAdmin",
                "MIMService",
                "MIMInstall"
            )
        }
    }
}

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName   = 'localhost'
            DomainName = 'contoso.com'
        }
    )
    WindowsFeatures = @(
        'AD-Domain-Services'
        'RSAT-AD-PowerShell'
        'DNS'
    )
    $adUsers = @(
        'MIMINSTALL'
        'MIMMA'
        'MIMSync'
        'MIMService'
        'MIMSSPR'
        'SharePoint'
        'SqlServer'
        'BackupAdmin'
        'MIMpool'
    )
    $adGroups = @(
        'MIMSyncAdmins'
        'MIMSyncOperators'
        'MIMSyncJoiners'
        'MIMSyncBrowse'
        'MIMSyncPasswordSet'
    )
}
